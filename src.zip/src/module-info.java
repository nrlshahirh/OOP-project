module latest {
	requires javafx.graphics;
	requires java.desktop;
	requires javafx.fxml;
	requires javafx.controls;
	exports test;
}