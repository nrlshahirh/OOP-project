// CONTROLLER FOR MENU

package test;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.scene.Node;

public class MainPage {
	
	private Stage stage;
	private Scene scene;
	
	@FXML
	public Button logoutbutton;
	
	@FXML
	public AnchorPane anchorPane; 
	
	public void EnterStart(ActionEvent event) throws IOException {
		
		Parent root = FXMLLoader.load(getClass().getResource("/LevelSelection.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void EnterInstructions(ActionEvent event) throws IOException {
		
		Parent root = FXMLLoader.load(getClass().getResource("/Instructions.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void EnterHighscore(ActionEvent event) throws IOException {

		Card.GetHighscore();
		Parent root = FXMLLoader.load(getClass().getResource("/HighScoreController.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}

	public void logout(ActionEvent event) throws IOException {

		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Logout");
		alert.setHeaderText("You're about to quit!");
		alert.setContentText("Are you sure to exit?");
		
		if(alert.showAndWait().get() == ButtonType.OK) {
			stage = (Stage) anchorPane.getScene().getWindow();

			stage.close();
		}
	}
}
