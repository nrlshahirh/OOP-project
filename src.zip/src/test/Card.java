package test;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javafx.animation.FadeTransition;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class Card extends StackPane {

	private Text text = new Text();
	public static int score_count = 0;
	private static Card selected = null;
	private static int clickCount = 2;
	public static int score_count1 = 0;
	private static String highscore = "";
	public static JFrame f;  
  
	public Card(String Value) {
    
		Rectangle border = new Rectangle(100, 100);
		border.setX(300);
		border.setY(300);
		border.setFill(Color.BLACK);
		border.setStroke(Color.YELLOW);
    
		text.setText(Value);
		text.setFont(Font.font(30));
		text.setFill(Color.GREEN);
    
		setAlignment(Pos.CENTER);
		getChildren().addAll(border, text);
    
		setOnMouseClicked(this::handleMouseClick);
	
		close();
	}

	public void handleMouseClick(MouseEvent event) {
		
		if (isOpen() || clickCount == 0) {
			
			return;
		}
		
		clickCount--;
		
		if (selected == null) {
			
			selected = this;
			open(() -> {});
		}
		
		else {

			open(() -> {

				if (!checkSame(selected)) {

					score_count=score_count+10;
					score_count1=1000-score_count*5;
					selected.close();
					this.close();
				}
	        
				selected = null;
				clickCount = 2;
	        
				if (Level.allOpen()) {
	        	
					displayScore();
				}
			});
		}
	}
 
	public static void GetHighscore() throws IOException {
	 
		FileReader readfile = null;
		BufferedReader reader = null;
	 
		readfile = new FileReader("C:/Users/User/Desktop/highscore.txt");
		reader = new BufferedReader(readfile);
		String line = reader.readLine();
		while (line != null) {
			
			Level.scores.add(line);
			line = reader.readLine();
		}
 
		try {
			reader.close();
		}
		
		catch (IOException e) {
// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 
	}
  
	public void open(Runnable action) {
		
		FadeTransition ft = new FadeTransition(Duration.seconds(0.5), text);
		ft.setToValue(1);
		ft.setOnFinished(e -> action.run());
		ft.play();
	}
  
	public void close() {
		
		FadeTransition ft = new FadeTransition(Duration.seconds(2), text);
		ft.setToValue(0);
		ft.play();
	}
  
	public boolean isOpen() {
		
		return text.getOpacity() == 1;
	}
  
	public boolean checkSame(Card other) {
	
		return text.getText().equals(other.text.getText());
	}
  
	/* public boolean checkAll () {

		return text.getText().matches(null);
	}*/
	public static void displayScore() {

		score_count1=1000-score_count*5;

		String name = JOptionPane.showInputDialog("Your mark is "+ score_count1+" !\n"+"Enter your name to save the game.");

		if(!(name==null)) {

			highscore = name + ": " + score_count1;
			f=new JFrame();  
			JOptionPane.showMessageDialog(f,"Game Saved.","Alert",JOptionPane.WARNING_MESSAGE); 
   	      	   
			File scorefile = new File("C:/Users/User/Desktop/highscore.txt");
      
			if(!scorefile.exists()) {
    	 
				try {

					scorefile.createNewFile();
				}
				
				catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			FileWriter writefile = null;
			BufferedWriter writer = null;
    	  
			try {
				
				writefile = new FileWriter(scorefile, true);
				writer = new BufferedWriter(writefile);
				writer.write(highscore+"\n");
			}
    	  
			catch(Exception e) {
    		  
			}
    	  
			finally {
				try {
					if (writer!= null) {
						writer.close();
					}
				}
    			  
				catch (Exception e) {}
			}
		}
      
		score_count=0;
		score_count1=0;
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	}
}