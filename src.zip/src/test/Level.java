package test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javafx.scene.layout.StackPane;

public class Level extends StackPane{
	
	protected static List<String> scores = new ArrayList<String>();
	protected static List<Card> cards = new ArrayList<Card>();
	
	public Level(int NUM_OF_PAIRS, int NUM_PER_ROW) {
		char c = 'A';
		
		for (int i = 0; i < NUM_OF_PAIRS; i++) {
			cards.add(new Card(String.valueOf(c)));
			cards.add(new Card(String.valueOf(c)));
		
			c++;
		}
		
		Collections.shuffle(cards);
		
		for (int i = 0; i < cards.size(); i++) {
			Card card = cards.get(i);
			card.setTranslateX(100 * (i % NUM_PER_ROW));
			card.setTranslateY(100 * (i / NUM_PER_ROW));
			
			getChildren().add(card);
		}
	}
	
	public static boolean allOpen() {
		
		for (Card card : cards) {
	    	
			if (!card.isOpen()) {
	    	  
				return false;
			}
		}
	    
		return true;
	}
}