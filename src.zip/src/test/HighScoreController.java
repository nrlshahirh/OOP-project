package test;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class HighScoreController implements Initializable{
		
	private Stage stage;
	private Scene scene;
		
	ObservableList<String> myScores = FXCollections.observableArrayList(Level.scores);
	@FXML
	public ListView<String> myListView;

	public void backtoMain(ActionEvent event) throws IOException {
			
		Parent root = FXMLLoader.load(getClass().getResource("/Menu.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	
	public void clearFile() throws IOException {
	
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Reset Highscore");
		alert.setHeaderText("The highscore will be reset !");
		alert.setContentText("Proceed?");
		
		if(alert.showAndWait().get() == ButtonType.OK) {
			
			myScores.clear();
			FileWriter fw = new FileWriter("C:/Users/User/Desktop/highscore.txt");
			PrintWriter pw = new PrintWriter(fw);
			pw.write("");
			pw.flush(); 
			pw.close();
			
			Alert a = new Alert(AlertType.INFORMATION);
			
			a.setHeaderText("The highscore has been reset!");
			
			a.show();
		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	Level.scores.clear();
	myListView.setItems(myScores);
	}
}