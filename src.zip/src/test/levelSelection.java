// CONTROLLER FOR LEVEL SELECTTION

package test;
	
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class levelSelection {
	public Stage stage;
	public Scene scene;
	Stage newWindow = new Stage();
	
	public void backtoMain(ActionEvent event) throws IOException {
		
		Parent root = FXMLLoader.load(getClass().getResource("/Menu.fxml"));
		stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
		
	public void level1Button(ActionEvent event) throws IOException {
			
		Level.cards.clear();
		Pane root = new Pane();
		root.setPrefSize(600, 400);
		
		Level level = new Level(3, 3);
		root.getChildren().add(level);
		
		scene = new Scene(root);
	
		BackgroundFill background_fill = new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, null);
		Background background = new Background(background_fill);
		root.setBackground(background);

		newWindow.setTitle("Level 1");
		newWindow.setScene(scene);
		newWindow.show();
	}
		
	
	public void level2Button(ActionEvent event) throws IOException {
		
		Level.cards.clear();
		Pane root = new Pane();
		root.setPrefSize(600, 400);
		
		Level level = new Level(6, 3);
		root.getChildren().add(level);
		
		scene = new Scene(root);

		BackgroundFill background_fill = new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, null);
		Background background = new Background(background_fill);
		root.setBackground(background);

		newWindow.setTitle("Level 2");
		newWindow.setScene(scene);
		newWindow.show();
	}
	
	public void level3Button(ActionEvent event) throws IOException {
		
		Level.cards.clear();
		Pane root = new Pane();
		root.setPrefSize(600, 400);
		
		Level level = new Level(8, 4);
		root.getChildren().add(level);
		
		scene = new Scene(root);
			
		BackgroundFill background_fill = new BackgroundFill(Color.BLACK, CornerRadii.EMPTY, null);
		Background background = new Background(background_fill);
		root.setBackground(background);

		newWindow.setTitle("Level 3");
		newWindow.setScene(scene);
		newWindow.show();		
	}	
}